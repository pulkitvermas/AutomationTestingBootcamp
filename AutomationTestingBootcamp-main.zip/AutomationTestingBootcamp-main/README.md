# AutomationTestingBootcamp
Link: https://rahulshettyacademy.com/dropdownsPractise/

and http://automationpractice.com/index.php?controller=authentication&back=my-account

Write 5 functional test cases (Manual) and then automate them

Test Plan Name Over TestLink:  Live Project_(Today's date)

Scenario finalized for Automation:

#### 1) Successful registration with valid data
      Working Perfectly Fine.

#### 2) Log in with a registered user in above step and place an order (End to End)
      Working Perfectly Fine Combined With Que 4.
      
#### 3) Negative Test Case: Booking Flight with same departure and arrival city
      Negative Testing was done. The search button was an input and not a button,
      also while entering the city names in departure and arrival it took the input of same the city name in both the fields which it should not.
      Hence, website not suitable for negative testing

#### 4) book a order than contact the customer care for that order
      Working Perfectly Fine, combined with Que 2.
      
#### 5) Negative Testing: Try to place a order without signing in
      Working Perfectly Fine, not able to order anything unless logged in or created a new account.
 
